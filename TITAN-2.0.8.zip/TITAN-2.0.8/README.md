TITAN - elecTric fIeld generaTion And maNipulation - is an open-source software package 
capable of (a) generating external electric fields by creating collections of point-charges 
around chemical systems, and (b) quantifying electric fields at any location based on a 
charge distribution, e. g. the local electric fields (LEF) experienced at the active site
of a (bio)chemical system, caused by the charged functional groups in distant regions.

Copyright (C) 2020 The TITAN Development Team

This file is part of TITAN

TITAN is free software; you can redistribute it and/or modify it under the terms of
the GNU General Public License as published by the Free Software Foundation;
either version 3 of the License, or (at your option) any later version.

TITAN is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTIBILITY or FINTESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public Lincense along with this program;
if not, see <http://www.gnu.org/licenses/>
